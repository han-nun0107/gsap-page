import { BrowserRouter, Link, Outlet, Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./Home";
import About from "./about";
import Info from "./info";

function Layout() {
  return (
    <>
      <header className="header">
        <div className="header-links">
          <Link to="/home" className="header-link">
            home
          </Link>
          <Link to="/about" className="header-link">
            about
          </Link>
          <Link to="/Info" className="header-link">
            info
          </Link>
        </div>
      </header>
      <Outlet />
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/Info" element={<Info />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
