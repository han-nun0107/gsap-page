function HeaderConLogo() {
  return (
    <div className="text-2xl font-black">
      <a
        href="./index.html"
        className=" text-white dark:text-white no-underline"
      >
        YouTube Portfolio
      </a>
    </div>
  );
}

export default HeaderConLogo;
