function FooterConHead() {
  return (
    <div className="no-underline">
      <p className="text-[2rem] font-black text-white">
        YouTube <br />
        Portfolio
      </p>
    </div>
  );
}

export default FooterConHead;
