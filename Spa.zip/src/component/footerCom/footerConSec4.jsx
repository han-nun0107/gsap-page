function FooterConSec4() {
  return (
    <div className="flex justify-start ml-[2%] text-white">
      &copy; 2025 by Han_nun Portfolio
    </div>
  );
}

export default FooterConSec4;
