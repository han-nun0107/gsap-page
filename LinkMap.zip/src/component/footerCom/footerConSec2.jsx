function FooterConSec2() {
  return (
    <div className="no-underline">
      <div className="text-white group">
        <a href="#" className="group-hover:underline text-white">
          개인정보 처리방침
        </a>
      </div>
      <div className="text-white group">
        <a href="#" className="group-hover:underline text-white">
          접근성 표시 정보
        </a>
      </div>
    </div>
  );
}

export default FooterConSec2;
