function FooterConSec3() {
  return <div className="text-white text-[2rem] font-semibold">저작권</div>;
}

export default FooterConSec3;
