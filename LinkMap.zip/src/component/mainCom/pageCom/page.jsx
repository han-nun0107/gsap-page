function Page() {
  return (
    <div className="grid grid-rows-[.1fr_1fr] grid-cols-[1fr_3fr_1fr]">
      <h1 className="col-span-3 ml-[1%] mt-[1%] text-white dark:text-black text-[2rem]">
        페이지
      </h1>
      <div></div>
      <div className="flex border border-white dark:border-black mb-[5%]"></div>
      <div></div>
    </div>
  );
}

export default Page;
