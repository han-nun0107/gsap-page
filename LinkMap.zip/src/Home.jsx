import Header from "./component/header";
import Main from "./component/main";
import Footer from "./component/footer";
import { useEffect, useState } from "react";

function Home({ menus }) {
  const [darkMode, setDarkMode] = useState(false);
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  const toggleTheme = () => {
    setDarkMode((prev) => !prev);
  };

  return (
    <>
      <div className="grid grid-rows-[.2fr_10fr_.8fr] bg-black dark:bg-black text-black dark:text-white ">
        <Header
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          toggleTheme={toggleTheme}
          menus={menus}
        />
        <Main />
        <Footer />
      </div>
    </>
  );
}

export default Home;
