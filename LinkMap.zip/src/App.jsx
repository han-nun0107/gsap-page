import { BrowserRouter, Link, Outlet, Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./Home";
import About from "./about";
import Info from "./info";

/* function Layout({ label, to }) {
  return (
    <>
      <header className="header">
        <div>Router Practice</div>
        <div className="header-links">
          <Link to={to} className="header-link">
            {label}
          </Link>
          <Link to={to} className="header-link">
            {label}
          </Link>
          <Link to={to} className="header-link">
            {label}
          </Link>
        </div>
      </header>
      <Outlet />
    </>
  );
} */

function App() {
  const menuItem = [
    { label: "홈", to: "/home" },
    { label: "소개", to: "/about" },
    { label: "정보", to: "/info" },
  ];

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout menus={menuItem} />}>
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/info" element={<Info />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
